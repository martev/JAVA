import static java.lang.System.out;
public class MultiThreaded {
	private String txt="";
	
	public MultiThreaded()
	{
		
	}
	
	public String Letters(String str) {
		String line="";
		for(int i=0; i<str.length();i++) { 
			if(str.charAt(i)!=' ') {
				line +=str.charAt(i);
				line+="\n";
			}
		}
		return line;
	}
	public String Words(String str) {
		String word="";
		for(int i=0; i<str.length();i++) { 
			if(str.charAt(i)!=' ') {
				word +=str.charAt(i);
			}else {
				word+="\n";
			}
		}
		return word;
	}
	public String Line(String str) {
		String line="";
		for(int i=0; i<str.length();i++) { 
			if(str.charAt(i)!='.'^str.charAt(i)!='!'^str.charAt(i)!='?') {
				line +=str.charAt(i);
			}else {
				line+=".\n";
			}
		}
		return line;
	}
}
