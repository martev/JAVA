// Студент: Мартин Евтимов, Факултетен номер: 46191з

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.*;

public class Multithreadedapplication {

	private JFrame frmMultithreadtext;
	private JTextArea txtrAddYouText;
	private JTextArea txtrLetters;
	private JTextArea txtrWords;
	private JTextArea txtrLines;
	private JScrollPane scrollPane_2;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Multithreadedapplication window = new Multithreadedapplication();
					window.frmMultithreadtext.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public Multithreadedapplication() {
		initialize();
	}
	private void initialize() {
		frmMultithreadtext = new JFrame();
		frmMultithreadtext.setTitle("MultiThreadTEXT");
		frmMultithreadtext.setBounds(100, 100, 770, 498);
		frmMultithreadtext.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMultithreadtext.getContentPane().setLayout(null);
		MultiThreaded text=new MultiThreaded();
		
		JButton btnNewButton = new JButton("RUN");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String txt=txtrAddYouText.getText();
				txt=text.Letters(txt);
				txtrLetters.setText(txt);
				//JOptionPane.showMessageDialog(null, txt);
				txt=txtrAddYouText.getText();
				txt=text.Words(txt);
				txtrWords.setText(txt);
				//JOptionPane.showMessageDialog(null, txt);
				txt=txtrAddYouText.getText();
				txt=text.Line(txt);
				txtrLines.setText(txt);
				//JOptionPane.showMessageDialog(null, txt);
			}
		});
		btnNewButton.setBounds(335, 213, 89, 23);
		frmMultithreadtext.getContentPane().add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 15, 315, 200);
		frmMultithreadtext.getContentPane().add(scrollPane);
		
		txtrAddYouText = new JTextArea();
		txtrAddYouText.setLineWrap(true);
		scrollPane.setViewportView(txtrAddYouText);
		txtrAddYouText.setText("Add you text here");
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(429, 15, 315, 200);
		frmMultithreadtext.getContentPane().add(scrollPane_1);
		
		
		txtrLetters = new JTextArea();
		scrollPane_1.setViewportView(txtrLetters);
		txtrLetters.setLineWrap(true);
		txtrLetters.setText("Letters");
		
		scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(429, 247, 315, 200);
		frmMultithreadtext.getContentPane().add(scrollPane_2);
		
		txtrLines = new JTextArea();
		scrollPane_2.setViewportView(txtrLines);
		txtrLines.setText("Lines");
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(10, 247, 315, 200);
		frmMultithreadtext.getContentPane().add(scrollPane_3);
		
		txtrWords = new JTextArea();
		scrollPane_3.setViewportView(txtrWords);
		txtrWords.setLineWrap(true);
		txtrWords.setText("Words");
		
		
	}
}
